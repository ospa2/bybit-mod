export function disableBodyScroll() {
    // Сохраняем текущую позицию скролла
    const scrollY = window.pageYOffset || document.documentElement.scrollTop;
    
    // Сохраняем позицию для восстановления
    document.body.setAttribute('data-scroll-y', scrollY.toString());
    
    // Блокируем скролл
    document.body.style.position = 'fixed';
    document.body.style.top = `-${scrollY}px`;
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.overflow = 'hidden';
    
    // Добавляем класс для дополнительной стилизации
    document.body.classList.add('modal-open');
}

export function enableBodyScroll() {
    // Получаем сохраненную позицию
    const scrollY = document.body.getAttribute('data-scroll-y');
    
    // Убираем класс
    document.body.classList.remove('modal-open');
    
    // Восстанавливаем стили
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    document.body.style.overflow = '';
    
    // Восстанавливаем позицию скролла
    if (scrollY) {
        window.scrollTo(0, parseInt(scrollY, 10));
        document.body.removeAttribute('data-scroll-y');
    }
}

